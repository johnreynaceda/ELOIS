<?php

namespace App\Http\Livewire\Client;

use Livewire\Component;
use WireUi\Traits\Actions;
use App\Models\RequestTransaction;
use DB;
class RequestDocument extends Component
{
    use Actions;
    public $request_modal = false;

    public $firstname, $lastname, $middlename, $birthdate, $address, $notes;
    public function render()
    {
        return view('livewire.client.request-document');
    }

    public function updatedRequestModal()
    {
        if (auth()->user()->user_information == null) {
            $this->dialog()->info(
                $title = 'Information Required',
                $description = 'Please update your information first.'
            );
            $this->request_modal = false;
        }
    }

    public function sendRequest()
    {
        $this->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'middlename' => 'required',
            'birthdate' => 'required',
            'address' => 'required',
            'notes' => 'required',
        ]);
        DB::beginTransaction();
        $request = RequestTransaction::create([
            'user_id' => auth()->user()->id,
            'firstname' => $this->firstname,
            'lastname' => $this->lastname,
            'middlename' => $this->middlename,
            'birthdate' => $this->birthdate,
            'address' => $this->address,
            'notes' => $this->notes,
        ]);
        DB::commit();
        $this->dialog()->success(
            $title = 'Request Sent',
            $description =
                'Your request has been sent. Please wait for the approval of the Office Staff.'
        );
        $this->request_modal = false;
        $this->emit('notarized');
    }
}
