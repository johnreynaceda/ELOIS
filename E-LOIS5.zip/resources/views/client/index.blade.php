<x-client-layout>
  <div class="grid grid-cols-1 gap-4 lg:col-span-2">
    <!-- Welcome panel -->
    <section aria-labelledby="profile-overview-title">
      <div class="overflow-hidden rounded-lg bg-white shadow">
        <h2 class="sr-only" id="profile-overview-title">Profile Overview</h2>
        <div class="bg-white p-6">
          <div class="sm:flex sm:items-center sm:justify-between">
            <div class="sm:flex sm:space-x-5">
              <div class="flex-shrink-0 ">
                <div class="flex justify-center items-center">
                  <x-svg.user class="h-20" />
                </div>
              </div>
              <div class="mt-4 text-center sm:mt-0 sm:pt-1 sm:text-left">
                <p class="text-sm font-medium text-gray-600">Welcome back,</p>
                <p class="text-xl font-bold text-gray-900 sm:text-2xl">{{ auth()->user()->name }}</p>
                <p class="text-sm font-medium text-gray-600">{{ auth()->user()->role->name }}</p>
              </div>
            </div>
            <div class="mt-5 flex justify-center sm:mt-0">
              <a href="{{ route('client.profile') }}"
                class="flex items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50">View
                profile</a>
            </div>
          </div>
        </div>
        <div class=" mx-6 mb-2  mt-2">
          @if (auth()->user()->user_information == null)
            <div class="rounded-md bg-yellow-50 p-4">
              <div class="flex">
                <div class="flex-shrink-0">
                  <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fill-rule="evenodd"
                      d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z"
                      clip-rule="evenodd" />
                  </svg>
                </div>
                <div class="ml-3">
                  <h3 class="text-sm font-medium text-yellow-800">Attention needed</h3>
                  <div class="mt-2 text-sm text-yellow-700">
                    <p>To submit an application, please first update your personal information. Just click "View
                      Profile". Thank You.</p>
                  </div>
                </div>
              </div>
            </div>
          @endif

        </div>
      </div>

    </section>

    <!-- Actions panel -->
    <section aria-labelledby="quick-links-title">
      <div
        class="divide-y divide-gray-200 overflow-hidden rounded-lg bg-gray-200 shadow sm:grid sm:grid-cols-2 sm:gap-px sm:divide-y-0">
        <h2 class="sr-only" id="quick-links-title">Quick links</h2>

        <livewire:client.request-document />

        <livewire:client.appointment-request />


      </div>
    </section>
  </div>
</x-client-layout>
