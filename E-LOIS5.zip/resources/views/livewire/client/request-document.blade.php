<div>
  <div wire:click="$set('request_modal', true)"
    class="rounded-tl-lg rounded-tr-lg sm:rounded-tr-none relative group bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-cyan-500">
    <div>
      <span class="rounded-lg inline-flex p-3 bg-teal-50 text-teal-700 ring-4 ring-white">
        <!-- Heroicon name: outline/clock -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="fill-gray-600" width="24" height="24">
          <path fill="none" d="M0 0h24v24H0z" />
          <path
            d="M19 22H5a3 3 0 0 1-3-3V3a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v12h4v4a3 3 0 0 1-3 3zm-1-5v2a1 1 0 0 0 2 0v-2h-2zm-2 3V4H4v15a1 1 0 0 0 1 1h11zM6 7h8v2H6V7zm0 4h8v2H6v-2zm0 4h5v2H6v-2z" />
        </svg>
      </span>
    </div>
    <div class="mt-8">
      <h3 class="text-lg font-medium">
        <a href="#" class="focus:outline-none">
          <!-- Extend touch target to entire panel -->
          <span class="absolute inset-0" aria-hidden="true"></span>
          Request Notarized Document
        </a>
      </h3>
      <p class="mt-2 text-sm text-gray-500">Doloribus dolores nostrum quia qui natus officia quod et
        dolorem. Sit repellendus qui ut at blanditiis et quo et molestiae.</p>
    </div>
    <span class="pointer-events-none absolute top-6 right-6 text-gray-300 group-hover:text-gray-400" aria-hidden="true">
      <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
        <path
          d="M20 4h1a1 1 0 00-1-1v1zm-1 12a1 1 0 102 0h-2zM8 3a1 1 0 000 2V3zM3.293 19.293a1 1 0 101.414 1.414l-1.414-1.414zM19 4v12h2V4h-2zm1-1H8v2h12V3zm-.707.293l-16 16 1.414 1.414 16-16-1.414-1.414z" />
      </svg>
    </span>
  </div>

  <x-modal wire:model.defer="request_modal" max-width="xl" align="center">
    <x-card title="REQUEST FORM">
      <div>
        <div>
          <div class="">
            <h3 class="text-base font-semibold leading-6 text-gray-900">Applicant Information</h3>
            <p class="mt-1 max-w-2xl text-sm text-gray-500">Personal details and application.</p>
          </div>
          <div class="border-t border-gray-200 px-4 py-5 sm:px-6">
            <dl class="grid grid-cols-1 gap-x-3 gap-y-3 sm:grid-cols-2">
              <div class="sm:col-span-1">
                <x-input label="First Name" wire:model.defer="firstname" placeholder="" />
              </div>
              <div class="sm:col-span-1">
                <x-input label="Middle Name" wire:model.defer="middlename" placeholder="" />
              </div>
              <div class="sm:col-span-1">
                <x-input label="Last Name" wire:model.defer="lastname" placeholder="" />
              </div>
              <div class="sm:col-span-1">
                <x-datetime-picker label="Birthdate" wire:model.defer="birthdate" without-time placeholder="" />
              </div>
              <div class="sm:col-span-2">
                <x-input label="Address" wire:model.defer="address" placeholder="" />
              </div>
              <div class="sm:col-span-2">
                <x-textarea label="Notes" wire:model.defer="notes" placeholder="write your notes" />
              </div>
            </dl>
          </div>
        </div>

      </div>

      <x-slot name="footer">
        <div class="flex justify-end gap-x-4">
          <x-button flat label="Cancel" x-on:click="close" />
          <x-button positive label="Request Send" wire:click="sendRequest" spinner="sendRequest"
            right-icon="arrow-right" />
        </div>
      </x-slot>
    </x-card>
  </x-modal>
</div>
