<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="c4d98dbd5badae901761ab6422fa3e70">
    AM/PM
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" x-model="input" x-on:input.debounce.150ms="onInput($event.target.value)" x-on:blur="emitInput" placeholder="12:00 AM" name="start_time" id="c4d98dbd5badae901761ab6422fa3e70" />

                    <div class="absolute inset-y-0 right-3 z-5 flex items-center justify-center">
                    <div class="flex items-center gap-x-2 my-auto">
                        <svg class="cursor-pointer w-4 h-4 hover:text-negative-500 transition-colors ease-in-out duration-150" x-cloak="x-cloak" x-show="!config.readonly &amp;&amp; !config.disabled &amp;&amp; input" x-on:click="clearInput" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
</svg>

                        <svg class="cursor-pointer w-5 h-5 text-gray-400 dark:text-gray-600" x-show="!config.readonly &amp;&amp; !config.disabled" x-on:click="toggle" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
</svg>
                    </div>
                </div>
            </div>

    
                </div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/c47508eef7e25b67ef14676b98c16f76.blade.php ENDPATH**/ ?>