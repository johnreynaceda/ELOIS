<a wire:loading.attr="disabled" wire:loading.class="!cursor-wait" href="http://127.0.0.1:8000/logout" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm leading-4 px-3 py-2     ring-red-500 text-white bg-red-500 hover:bg-red-600 hover:ring-red-600
    dark:ring-offset-slate-800 dark:bg-red-700 dark:ring-red-700
    dark:hover:bg-red-600 dark:hover:ring-red-600" onclick="event.preventDefault();
              this.closest('form').submit();">
            <svg class="w-3.5 h-3.5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
</svg>
    
    Logout

    
    </a>
