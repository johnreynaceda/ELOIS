<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm leading-4 px-3 py-2     ring-positive-500 text-white bg-positive-500 hover:bg-positive-600 hover:ring-positive-600
    dark:ring-offset-slate-800 dark:bg-positive-700 dark:ring-positive-700
    dark:hover:bg-positive-600 dark:hover:ring-positive-600" wire:click="$set('add_directory', true)">
            <svg class="w-3.5 h-3.5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
</svg>
    
    New Directory

    
    </button>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/f69b9affa647b9f70859a59f9233dd98.blade.php ENDPATH**/ ?>