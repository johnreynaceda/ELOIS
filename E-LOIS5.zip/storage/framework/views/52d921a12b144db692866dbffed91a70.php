<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secretary-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secretary-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <header>
    <h2 class="text-xl font-bold uppercase text-gray-700">Appointments</h2>
  </header>

  <div class="flex  p-10 gap-10 ">
    <div class="flex-1">
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('secretary.appointment', [])->html();
} elseif ($_instance->childHasBeenRendered('HQwuQd5')) {
    $componentId = $_instance->getRenderedChildComponentId('HQwuQd5');
    $componentTag = $_instance->getRenderedChildComponentTagName('HQwuQd5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HQwuQd5');
} else {
    $response = \Livewire\Livewire::mount('secretary.appointment', []);
    $html = $response->html();
    $_instance->logRenderedChild('HQwuQd5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    
  </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\resources\views/secretary/appointment.blade.php ENDPATH**/ ?>