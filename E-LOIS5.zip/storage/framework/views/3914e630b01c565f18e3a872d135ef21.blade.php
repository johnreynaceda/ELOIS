<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400">
    Make
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm pr-8" placeholder="" />

                    <div class="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none
                text-secondary-400">
                                    <span class="flex items-center justify-center pr-1">
                        ₱
                    </span>
                            </div>
            </div>

    
    </div>
