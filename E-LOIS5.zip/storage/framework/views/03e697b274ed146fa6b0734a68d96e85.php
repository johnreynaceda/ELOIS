<div>
  <div class="mt-10">
    <h1 class="text-center text-xl font-bold">REQUEST OF DOCUMENTS</h1>
  </div>
  <div class="mt-5">
    <table id="example" class="table-auto" style="width:100%">
      <thead class="font-normal">
        <tr>
          <th class="border text-left px-2 text-sm font-medium text-gray-600 py-2">CLIENT FULLNAME
          </th>
          <th class="border text-left px-2 text-sm font-medium text-gray-600 py-2">ADDRESS</th>
          <th class="border text-left px-2 text-sm font-medium text-gray-600 py-2">NOTES
          </th>
          <th class="border text-left px-2 text-sm font-medium text-gray-600 py-2">REQUESTED DATE</th>
        </tr>
      </thead>
      <tbody class="">

        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="border text-gray-600  px-3 py-1">
              <?php echo e($request->user->user_information->firstname . ' ' . $request->user->user_information->lastname); ?></td>
            <td class="border text-gray-600  px-3 py-1">
              <?php echo e($request->user->user_information->address); ?>

            </td>
            <td class="border text-gray-600  px-3 py-1">
              <?php echo e($request->notes); ?>

            </td>
            <td class="border text-gray-600  px-3 py-1">
              <?php echo e(\Carbon\Carbon::parse($request->updated_at)->format('F d, Y')); ?>

            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\resources\views/reports/request_of_documents.blade.php ENDPATH**/ ?>