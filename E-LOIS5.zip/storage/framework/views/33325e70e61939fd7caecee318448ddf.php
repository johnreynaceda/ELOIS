<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     text-slate-500 hover:bg-slate-100 ring-slate-200 dark:text-slate-400
    dark:hover:bg-slate-700 dark:ring-slate-600 dark:ring-offset-slate-700 rounded-lg shrink-0" x-show="!monthsPicker" x-on:click="nextMonth">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
</svg>
    
    

    
    </button>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/896d7d3cf166f6bfec33ad5dece0f31d.blade.php ENDPATH**/ ?>