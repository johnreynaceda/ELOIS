<div class="">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="20f35e630daf44dbfa4c3f68f5399d8c">
    Select Status
</label>
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500" wire:model="model" name="model" id="20f35e630daf44dbfa4c3f68f5399d8c">
         <option>Active</option>
   <option>Pending</option>
   <option>Stuck</option>
   <option>Done</option>     </select>

    
                </div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/9a6ea7e4503247acca919e6ef76e22b6.blade.php ENDPATH**/ ?>