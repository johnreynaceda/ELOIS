<div class="">
            <div class="flex justify-between mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="46b83674d1a52e84f8c820eb64c53574">
    Message
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <textarea autocomplete="off" rows="4" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" placeholder="write your remarks" wire:model.defer="remarks" name="remarks" id="46b83674d1a52e84f8c820eb64c53574"></textarea>

            </div>

    
                </div>
