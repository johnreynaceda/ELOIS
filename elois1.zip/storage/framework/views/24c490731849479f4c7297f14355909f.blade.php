<a wire:loading.attr="disabled" wire:loading.class="!cursor-wait" href="http://127.0.0.1:8000/client/dashboard" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm leading-4 px-3 py-2     ring-gray-700 text-white bg-gray-700 hover:bg-gray-900 hover:ring-gray-900
    dark:ring-offset-gray-800 dark:bg-gray-700 dark:ring-gray-700
    dark:hover:bg-gray-600 dark:hover:ring-gray-600">
            <svg class="w-3.5 h-3.5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
</svg>
    
    Back

    
    </a>
