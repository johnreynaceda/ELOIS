<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-negative-500 text-white bg-negative-500 hover:bg-negative-600 hover:ring-negative-600
    dark:ring-offset-slate-800 dark:bg-negative-700 dark:ring-negative-700
    dark:hover:bg-negative-600 dark:hover:ring-negative-600">
    
    Reject Request

    
    </button>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/59eae424c1f932f425c6c47fa35036a8.blade.php ENDPATH**/ ?>