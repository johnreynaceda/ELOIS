<div>
  <x-button rounded right-icon="arrow-right" label="Manage" xs positive
    href="{{ route('staff.manage-client', ['id' => $getState()]) }}" />
</div>
