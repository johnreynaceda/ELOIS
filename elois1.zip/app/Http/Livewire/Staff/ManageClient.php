<?php

namespace App\Http\Livewire\Staff;

use Livewire\Component;
use App\Models\UserInformation;
use App\Models\RequestTransaction;
use Livewire\WithPagination;
use WireUi\Traits\Actions;

class ManageClient extends Component
{
    use Actions;
    use WithPagination;
    public $client_id;
    public $request_count;

    public function mount()
    {
        $this->client_id = request()->id;
        $this->request_count = RequestTransaction::where(
            'user_id',
            $this->client_id
        )->count();
    }
    public function render()
    {
        return view('livewire.staff.manage-client', [
            'client_details' => UserInformation::where(
                'user_id',
                $this->client_id
            )->first(),
            'client_requests' => RequestTransaction::where(
                'user_id',
                $this->client_id
            )->paginate(5),
        ]);
    }

    public function doneRequest($id)
    {
        $request = RequestTransaction::where('id', $id)->first();
        $request->update([
            'status' => 3,
        ]);

        $this->dialog()->success(
            $title = 'Request Done',
            $description = 'Request has been marked as done.'
        );
        $this->emit('requestApproved');
    }
}
