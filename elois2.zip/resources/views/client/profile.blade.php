<x-client-layout>
  <div class="grid grid-cols-1 gap-4 lg:col-span-2">
    <livewire:client.profile />
  </div>
</x-client-layout>
