<div>
  <div>
    {{ $this->table }}
  </div>
</div>
