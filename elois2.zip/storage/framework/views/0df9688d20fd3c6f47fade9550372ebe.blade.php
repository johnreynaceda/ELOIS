<div class="">
            <label class="block text-sm font-medium text-negative-600 mb-1" for="0a37f8e3bda28bb2ded9b3af3211e5cc">
    Directory
</label>
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-negative-400 focus:ring-negative-500 focus:border-negative-500 text-negative-500
                dark:border-negative-600 dark:text-negative-500" wire:model="directory_id" name="directory_id" id="0a37f8e3bda28bb2ded9b3af3211e5cc">
         <option selected hidden>Select Directory</option>     </select>

    
            <p class="mt-2 text-sm text-negative-600">
        The directory id field is required.
    </p>
    </div>
