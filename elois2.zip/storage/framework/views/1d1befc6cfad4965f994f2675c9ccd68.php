<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-negative-600" for="8ad75c5a8821cc294f189181722acb56">
    Last Name
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="text-negative-900 dark:text-negative-600 placeholder-negative-300 dark:placeholder-negative-500 border border-negative-300 focus:ring-negative-500 focus:border-negative-500 dark:bg-secondary-800 dark:border-negative-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm pr-8" wire:model.defer="lastname" placeholder="" name="lastname" id="8ad75c5a8821cc294f189181722acb56" />

                    <div class="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none
                text-negative-500">
                                    <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
</svg>
                            </div>
            </div>

    
            <p class="mt-2 text-sm text-negative-600">
        The lastname field is required.
    </p>
    </div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/c351c43461e6fa303805b02f11b7159a.blade.php ENDPATH**/ ?>