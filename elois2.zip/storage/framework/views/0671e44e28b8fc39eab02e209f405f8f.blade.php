<div class="">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="c4ef352f74e502ef5e7bc98e6f4e493d">
    Document
</label>
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500" wire:model="category" name="category" id="c4ef352f74e502ef5e7bc98e6f4e493d">
         <option>Deed of Sale</option>
    <option>Affidavit of Loss</option>     </select>

    
                </div>
