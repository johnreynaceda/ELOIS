<div class="">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400 mb-1" for="1b7c5c0455b63091c985ac75f0e9ff51">
    Lawyer
</label>
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500" wire:model="lawyer_id" name="lawyer_id" id="1b7c5c0455b63091c985ac75f0e9ff51">
         <option selected hidden>Select Lawyer</option>
                      <option value="1">Pearl Craft</option>
                      <option value="2">Alexa Collier</option>     </select>

    
                </div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/c7be1f56176730bffa8a9e3e37249d78.blade.php ENDPATH**/ ?>