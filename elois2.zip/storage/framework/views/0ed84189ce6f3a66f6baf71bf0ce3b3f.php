<div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400" for="342f5c77ed008542e78094607ce1f7f3">
    First Name
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" wire:model.defer="firstname" placeholder="" name="firstname" id="342f5c77ed008542e78094607ce1f7f3" />

            </div>

    
                </div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/431d3669cfd1fc7125959b351f644d82.blade.php ENDPATH**/ ?>