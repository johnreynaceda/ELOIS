<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-positive-500 text-positive-600 hover:bg-positive-100
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 dark:ring-positive-700" x-on:click="Save and Close">
    
    Cancel

            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
</svg>
    
    </button>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\E-LOIS\storage\framework\views/6cf7bca5fff52712405f176a1a374c67.blade.php ENDPATH**/ ?>